#!bin/bash

filename=$1
cat < $filename | 

echo "Words - start with ‘s’ and is not follow by ‘a’"

echo 

awk '{
        for(i=1; i<=NF; i++) {
                tmp=match($i, /^s[b-z]/)
                if(tmp) {
                        print $i
                }
        }
}' $filename

echo

echo "Word starts with ‘w’ and is followed by ‘h’"

echo

awk '{
        for(i=1; i<=NF; i++) {
                tmp=match($i, /^w[h]/)
                if(tmp) {
                        print $i
                }
        }
}' $filename

echo

echo "Word starts with ‘t’ and is followed by ‘h’"

echo  

awk '{
        for(i=1; i<=NF; i++) {
                tmp=match($i, /^t[h]/)
                if(tmp) {
                        print $i
                }
        }
}' $filename

echo

echo "Word starts with ‘a’ and is not followed by ‘n’"

echo  

awk '{
        for(i=1; i<=NF; i++) {
                tmp=match($i, /^a[a-mo-z]/)
                if(tmp) {
                        print $i
                }
        }
}' $filename
