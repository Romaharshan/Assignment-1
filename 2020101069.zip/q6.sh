#!/bin/bash

file='contacts.csv'

if [ -f "$file" ];   #if file is not already present create a add file 

then
{
    echo -n ""

}

else
{
    echo "fname","lname","mobile","off" > contacts.csv
    file=contacts.csv
}
fi

while getopts ":C:f:l:k:n:ado:c:v:" flags;
do
{
    case $flags in
    v)
        val=$OPTARG;
        ;;
    C)
        com=$OPTARG;
        ;;
    c)
        col=$OPTARG;
        ;;
    f)
        first=$OPTARG; 
        ;;
    k)
        k=$OPTARG;
        ;;
    l)
        last=$OPTARG;
        ;;
    n)
        mobilenum=$OPTARG;
        ;;
    o)
        off=$OPTARG;
        ;;
    d)
        awk 'NR == 1; NR > 1 {print $0 | "sort -rk1"}'
        exit 0
        ;;
    a)
        awk 'NR == 1; NR > 1 {print $0 | "sort -k1"}'
        exit 0
        ;;

    *) echo "$flag doesn't exist"; exit ;;
    esac
}
done


if  [[ $com == "insert" ]];
    then
    {
       echo -n >> $file 
       echo $first,$last,$mobilenum,$off >> $file
    }
 
    elif [[ $com == "search" ]]; then

    if [[ $col == "fname" ]];
     then
        awk -F, -v add="$val" '$1==add' contacts.csv

    elif [[ $col == "lname" ]]; 
    then
        awk -F, -v add="$val" '$2==add' contacts.csv

    elif [[ $col == "mobile" ]]; 
    then
        awk -F, -v add="$val" '$3==add' contacts.csv

    fi

    if [[ $com == "display" ]]

    then
    {
        echo -n ""
    }

    if [[ $com == "delete" ]]; then
    {
       awk -v add="$val" -F, '$1==add' $file >> /dev/null

        sed -i "/${val}/d" $file
    }

    if [[ $com == "edit" ]]; then
    {
        newline=$(awk -v add="$k" -F, '$1==add{print NR":"$0}' $file)
        newline=$(echo "${newline%%:*}")
        if [ -z "$newline" ]; then
            {
                echo -n ""
            }
        else
            {
                sed -i "${newline}s/.*/${fname},${lname},${number},${off}/" $file
            }
        fi
    }



fi

exit
   