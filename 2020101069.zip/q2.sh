#!bin/bash

filename=$1
cat < $filename | awk '{print $NF}' > dob.txt 

var=$(cat dob.txt | wc -l) 

while read line
do

leng=${#line}

#echo $leng

declare d
declare m
declare y

name=${line:0:leng-10}

d1=${line:leng-10:2}
m1=${line:leng-7:2}
y1=${line:leng-4:4}

d=$d1
m=$m1
y=$y1

#echo $d1
#echo $m1
#echo $y1

yy=`date "+%Y"`
mm=`date "+%m"`
dd=`date "+%d"`

if [ $y -le $yy ]

then

yyy=`expr $yy - $y`
mmm=`expr $mm - $m`
#ddd=`expr $dd - $d`

if [ $m -gt $mm ]

then

yyy=`expr $yyy - 1`
mmm=`expr $mmm + 12`

fi

if [ $d -gt $dd ]

then
ddd=`expr $d - $dd`
ddd=`expr 31 - $ddd`

else

ddd=`expr $dd - $d`

fi

fi

if [ $m == $mm ]

then

if [ $d -gt $dd ]

then

ddd=`expr $d - $dd`
ddd=`expr 31 - $ddd`
mmm=`expr 11`
yyy=`expr $yyy - 1`

fi
fi

echo "$name $yyy" >> date.txt

done < "$filename"
