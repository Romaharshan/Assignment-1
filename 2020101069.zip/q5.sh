#!/bin/bash

ls -lSR > output.txt
cat output.txt | awk '{        
        tmp=match($1, /^d/)
        if(tmp) {
		print $2, $9
		}
}' | sort -Vr  > final.txt

cat output.txt | awk '{        
        tmp=match($1, /^-/)
        if(tmp) {
                print $5, $9
        }
        
}' | sort -Vr  > files_order.txt

echo

echo Directories:

echo

cat final.txt | awk '{print $2, ", " $1 "file(s)"}'

echo

echo Files:

echo

cat files_order.txt | awk '{print $2}'
