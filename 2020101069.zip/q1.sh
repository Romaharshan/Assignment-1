#!/bin/bash

inputfile=$1

#5g is for all variables after 4th variable to be masked as '#'

sed 's/\w/#/5g' $inputfile > output.txt
